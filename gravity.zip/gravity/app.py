from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# the name of the secret file and the size to match
SECRET_FILE = "/var/www/html/gravity/tesseract/light"
FILE_SIZE_TO_MATCH = 24388  # in bytes


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    # get the uploaded file
    uploaded_file = request.files["file"]

    # check if the file exists
    if not uploaded_file:
        return render_template("result.html", message="No file uploaded.")
    
    # get the file size
    file_size = len(uploaded_file.read())

    # check if the size matches
    if file_size == FILE_SIZE_TO_MATCH:
        # show the secret file
        with open(SECRET_FILE, "r") as f:
            secret_content = f.read()
        return render_template("result.html", message="Match found!", secret=secret_content)
    else:
        return render_template("result.html", message="Size does not match.")


if __name__ == "__main__":
    app.run(debug=True)

