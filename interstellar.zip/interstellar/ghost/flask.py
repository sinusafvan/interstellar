from flask import Flask, request, render_template_string
import binascii

app = Flask(__name__)

# Define the route for the HTML form
@app.route('/', methods=['GET', 'POST'])
def index():
    # If the form is submitted
    if request.method == 'POST':
        # Check if an image file was uploaded
        if 'image' not in request.files:
            return 'No image file selected'

        image = request.files['image']
        # Read the image file contents
        image_contents = image.read()

        # Scan the image contents for hexadecimal-encoded text
        try:
            hex_string = image_contents.hex()
            decoded_text = binascii.unhexlify(hex_string).decode('utf-8')
            return f'Decoded text: {decoded_text}'
        except:
            return 'No hexadecimal-encoded text found in the image'

    # If the form is not submitted, render the HTML template
    return render_template_string('''
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>Image Scanner</title>
          </head>
          <body>
            <h1>Image Scanner</h1>
            <form method="POST" enctype="multipart/form-data">
              <input type="file" name="image">
              <br><br>
              <input type="submit" value="Scan">
            </form>
          </body>
        </html>
    ''')

if __name__ == '__main__':
    app.run(debug=True)

